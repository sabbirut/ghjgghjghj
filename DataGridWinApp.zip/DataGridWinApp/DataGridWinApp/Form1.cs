﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace DataGridWinApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server = .;Database=test;UID=sabbir;Password=Flora@123;");

            SqlCommand cmd = new SqlCommand("select * from [test].[dbo].[TBL_TARGET] where name='"+textBox1.Text+"'", con);

            try
            {

                SqlDataAdapter da = new SqlDataAdapter();

                da.SelectCommand = cmd;

                DataTable dt = new DataTable();

                da.Fill(dt);

                BindingSource bsource = new BindingSource();

                bsource.DataSource = dt;

                dataGridView1.DataSource = bsource;

            }

            catch (Exception ec)
            {

                MessageBox.Show(ec.Message);

            }

            //SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=test;User id=sabbir;Password=Flora@123;");
            //SqlCommand cmd = new SqlCommand("select * from [test].[dbo].[TBL_TARGET] where name="+textBox1.Text , conn);
            //cmd.CommandType = CommandType.Text;
            //conn.Open();
            ////cmd.ExecuteNonQuery();
            

            //SqlDataAdapter sda = new SqlDataAdapter();
            //sda.SelectCommand = cmd;
            //DataTable dt = new DataTable();
            //sda.Fill(dt);
            //BindingSource bs = new BindingSource();
            //bs.DataSource = dt;
            //dataGridView1.DataSource = bs;
            //conn.Close();
        }
    }
}
